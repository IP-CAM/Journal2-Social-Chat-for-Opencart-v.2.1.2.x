<?php
// Heading
$_['heading_title']       = 'Social Chat';
 
// Text
$_['text_module']         = 'Social Chat';
$_['text_edit']           = 'Konfigurasi Social Chat';
$_['text_success']        = 'Success: Anda telah berhasil mengupdate modul Social Chat!';
 
// Entry
$_['entry_code_line']     = 'User ID Line At:';
$_['entry_code_messenger']= 'Facebook profile ID:';
$_['entry_code_wa']		  = 'No. WhatsApp:';
$_['entry_code_bbm']	  = 'PIN BBM:';
$_['entry_code_sms']	  = 'No. Telephone untuk SMS:';
$_['entry_code_lineid']	  = 'Line ID:';




$_['entry_status']        = 'Status:';
 
// Error
$_['error_permission']    = 'Warning: Anda tidak memiliki hak akses untuk memodifikasi Modul Social Chat!';
$_['error_code']          = 'PERHATIAN!: Silahkan masukkan kode pada kolom, untuk status social chat yang Diaktifkan';