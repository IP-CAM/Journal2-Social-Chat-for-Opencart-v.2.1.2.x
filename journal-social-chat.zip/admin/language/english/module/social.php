<?php
// Heading
$_['heading_title']       = 'Social Chat';
 
// Text
$_['text_module']         = 'Social Chat';
$_['text_edit']           = 'Configuration Social Chat';
$_['text_success']        = 'Success: You have modified Social Chat Modul!';
 
// Entry
$_['entry_code_line']     = 'User ID Line At:';
$_['entry_code_messenger']= 'Facebook profile ID:';
$_['entry_code_wa']		  = 'WhatsApp Number:';
$_['entry_code_bbm']	  = 'BBM PIN:';
$_['entry_code_sms']	  = 'Your SMS Phone Number:';
$_['entry_code_lineid']	  = 'Line ID:';




$_['entry_status']        = 'Status:';
 
// Error
$_['error_permission']    = 'WARNING: You do not have permission to modify Social Chat Modul!';
$_['error_code']          = 'WARNING!: Please input Code in the Column, for social chat that you want to active';